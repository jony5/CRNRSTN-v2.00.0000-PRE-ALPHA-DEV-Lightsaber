using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Xml;

namespace XMLParser
{
    public class GiftType
    {
        private string _name;
        private ArrayList _nodeList = new ArrayList();

        #region properties
        public string Name
        {
            get
            {
                return this._name;
            }
            set 
            {
                this._name = value;
            }

        }

        public ArrayList NodeList
        {
            get 
            {
                return this._nodeList;
            }
            set
            {
                _nodeList = value;
            }
        
        }
#endregion

        public GiftType(string name)
        {
            this._name = name;
        }

        public GiftType(string name, XmlNode node)
        {
            this._name = name;
            this._nodeList.Add(node);
        }
    }
}
