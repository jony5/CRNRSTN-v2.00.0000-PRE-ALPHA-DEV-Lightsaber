using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Net;
using System.IO;

namespace XMLParser
{
    public class FTPHandler
    {
        private string _ftpSite = ConfigurationSettings.AppSettings["FTPSite"];
        private string _userName = ConfigurationSettings.AppSettings["FTPUserName"];
        private string _password = ConfigurationSettings.AppSettings["FTPPassword"];
        private bool _useSSL =  Convert.ToBoolean(ConfigurationSettings.AppSettings["FTPUseSSL"]);
        private string _fileToUpload = string.Empty;
        private string _fileName = string.Empty;


        public void UploadFile(string filePath,string fileName)
        {
            _fileToUpload = filePath;
            _fileName = fileName;
            
            
            uploadFile();
        
        }

        private void uploadFile()
        {
            StreamReader sourceStream = new StreamReader(_fileToUpload);
            string statusCode, statusDescription;

            statusCode = statusDescription = string.Empty;
            
            try
            {
                //create request object
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(_ftpSite + _fileName);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.KeepAlive = false;

                request.Credentials = new NetworkCredential(_userName,_password);
                request.EnableSsl = _useSSL;
                
                
                byte[] fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());

                request.ContentLength = fileContents.Length;

                Stream requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                //Notifications.Notification.Notify("File Upload Status for " + _fileToUpload + "\nStatusCode:" + response.StatusCode + "\n" + response.StatusDescription);
                statusDescription = response.StatusDescription;
                statusCode = response.StatusCode.ToString();

            }
            catch (Exception ex)
            {
                Notifications.ErrorHandling.LogException(ex,"Error FTPing file : " + _fileToUpload + "\nStatusCode:" + statusCode + "\nStatusDescription:" + statusDescription);
            }
            finally
            {
                sourceStream.Close();
            }

        }

    }
}
