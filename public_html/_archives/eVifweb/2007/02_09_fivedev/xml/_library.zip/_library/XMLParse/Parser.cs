using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Configuration;
using System.IO;
using System.Collections;


namespace XMLParser
{
    class Parser
    {
        private string _xmlParseFile = ConfigurationSettings.AppSettings["FileToParse"];
        private string _imagePathToStrip = ConfigurationSettings.AppSettings["ImagePathToStrip"];
        private string _xmlResultsPath = ConfigurationSettings.AppSettings["ResultsPath"];
        private bool _useFTP = Convert.ToBoolean(ConfigurationSettings.AppSettings["UseFTP"]);
        private ArrayList _giftTypes = new ArrayList();
        private XmlDocument _xmlDoc = new XmlDocument();
        private FTPHandler _ftpHandler = new FTPHandler();

        #region constructors
        public Parser()
        {

        }
        #endregion

        static void Main(string[] args)
        {
            //create instance of the class
            Parser parser = new Parser();
            parser.ReadXML();

            //Console.ReadLine();
            Notifications.Notification.Notify("New File received and parsed");
          
        }


        private void ReadXML()
        {
            try
            {
                _xmlDoc.Load(_xmlParseFile);
                XmlNodeList nodeList = _xmlDoc.GetElementsByTagName("product");
                char[] seperator = { ',' };
                XmlNode tempNode;
                XmlAttribute attr;
                foreach (XmlNode node in nodeList)
                {
                    //only process the node if it's in stock
                    if(node.Attributes["oos"].Value == "0")
                    {
                        //strip the imageurls in the nodes
                        tempNode = StripImageURL(node);
                        //remove pipage attribute
                        attr = tempNode.Attributes["pippage"];
                        tempNode.Attributes.Remove(attr);

                        //get the gift type names
                        string[] giftTypeNames = node.Attributes["gifttype"].Value.Split(seperator);
                        foreach (string giftTypeName in giftTypeNames)
                        { 
                            //remove spacing and insert node
                            InsertNode(tempNode, giftTypeName.Replace("+","plus").Replace(" ",""));
                        }
                    }
                }

                //lets create the xml files
                foreach (GiftType giftType in _giftTypes)
                {
                    CreateXMLFile(giftType);
                }
                
            }
            catch (Exception ex)
            {
               Notifications.ErrorHandling.LogException(ex);

            }
            
            

        }

        private XmlNode StripImageURL(XmlNode node)
        {
            
            //small
            node.Attributes["smallimage"].Value = node.Attributes["smallimage"].Value.Replace(_imagePathToStrip, "");
            //medium
            node.Attributes["mediumimage"].Value = node.Attributes["mediumimage"].Value.Replace(_imagePathToStrip, "");
            //large
            node.Attributes["largeimage"].Value = node.Attributes["largeimage"].Value.Replace(_imagePathToStrip, "");
            //extralarge
            node.Attributes["extralargeimage"].Value = node.Attributes["extralargeimage"].Value.Replace(_imagePathToStrip, "");


            return node;
        
        }
      
        /// <summary>
        /// insert node into appropriate node list
        /// </summary>
        /// <param name="node"></param>
        /// <param name="giftType"></param>
        private void InsertNode(XmlNode node, string giftTypeName)
        { 
        
            //check to see if the nodelist exist. if it doesn't then create a new one
            if(DoesGiftTypeExists(giftTypeName))
            {
                //use existing gift type
                GiftType giftType = GetGiftType(giftTypeName);
                giftType.NodeList.Add(node);
            
            }
            else //create new gift type
            {
                _giftTypes.Add(new GiftType(giftTypeName,node));
            }
        }
        private GiftType GetGiftType(string giftTypeName)
        {
            foreach (GiftType giftType in _giftTypes)
            {
                if (giftType.Name == giftTypeName)
                    return giftType;
            }

            //GiftType could not be found so create a new one
            return new GiftType(giftTypeName);
        
        }
        private bool DoesGiftTypeExists(string pGiftType)
        {
            foreach (GiftType giftType in _giftTypes)
            {
                if (giftType.Name == pGiftType)
                    return true;
            }
            return false;
        
        }
        private void CreateXMLFile(GiftType giftType)
        {
            string fileName = "xml" + giftType.Name + ".xml";
            string filePath = _xmlResultsPath + fileName;
            
            StreamWriter writer = new StreamWriter(filePath);

            writer.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            writer.WriteLine("<ProductList>");

            foreach (XmlNode node in giftType.NodeList)
            { 
                writer.WriteLine(node.OuterXml);         
            }

            writer.WriteLine("</ProductList>");
            writer.Close();

            if(_useFTP)
                _ftpHandler.UploadFile(filePath, fileName);   

        }
    }
}
