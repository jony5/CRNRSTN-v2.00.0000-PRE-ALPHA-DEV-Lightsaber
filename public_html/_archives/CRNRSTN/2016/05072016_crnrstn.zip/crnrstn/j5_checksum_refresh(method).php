<?php

/* 
// J5
// Code is Poetry */
require('_crnrstn.root.inc.php');
include_once($ROOT . '_crnrstn.config.inc.php');

require($oUSER->getEnvParam('DOCUMENT_ROOT').$oUSER->getEnvParam('DOCUMENT_ROOT_DIR').'/common/inc/fh/session.inc.php');
echo "You don't want to run this...do you?<br><i>I will refresh crc32 checksums...</i><br><br>";

//
// ACTIVITY LOGGING
try{
	
	$queryDescript_ARRAY = array(
	'crnrstn_method_METHODID' => 0, 'crnrstn_method_METHODID_SOURCE' => 1
	);
	
	//
	// DB/UN IN CONFIG FILE TAKES PRECEDENCE.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn00');
	$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection();

	$query = 'SELECT `crnrstn_method`.`METHODID`, `crnrstn_method`.`METHODID_SOURCE` FROM `crnrstn_method`;';
	
	$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);
	
	//
	// REMAIN STILL WHILE YOUR LIFE IS EXTRACTED
	$ROWCNT=0;
	do {
		if ($result = $mysqli->store_result()) {
			while ($row = $result->fetch_row()) {
				foreach($row as $fieldPos=>$value){
					//
					// STORE RESULT
					#echo "ROW :: ".$ROWCNT.",FIELDPOS :: ".$fieldPos.",VAL :: ".$value."<br>";
					$result_ARRAY[$ROWCNT][$fieldPos]=$value;
					
				}
				$ROWCNT++;
			}
			$result->free();
		}

		if ($mysqli->more_results()) {
			//
			// END OF RECORD. MORE TO FOLLOW.
		}
	} while ($mysqli->next_result());
	
} catch( Exception $e ) {

	//
	// LOG ERROR FOR DB ACTIVITY LOGGING
	$oENV->oLOGGER->captureNotice('CRNRSTN error notification :: mysqli query failed', LOG_NOTICE, $e->getMessage());
}

	
$query='';
for($rownum=0; $rownum<sizeof($result_ARRAY); $rownum++){

	$crnrstn_method_METHODID_SOURCE = $result_ARRAY[$rownum][$queryDescript_ARRAY['crnrstn_method_METHODID_SOURCE']];
	$crnrstn_method_METHODID = $result_ARRAY[$rownum][$queryDescript_ARRAY['crnrstn_method_METHODID']];
	#echo 'Building SQL update for '.$crnrstn_examples_TECHSPECID_SOURCE.'...<br>';
	
	//
	// CALC CHECKSUM
	$tmp_crc32=crc32($crnrstn_method_METHODID_SOURCE);
	
	//
	// BUILD CHECKSUM UPDATE SQL 
	
	#$query .= 'UPDATE `crnrstn_examples` SET `crnrstn_examples`.`METHODID`="'.$tmp_crc32.'" WHERE `crnrstn_examples`.`METHODID`="'.$crnrstn_method_METHODID.'";';
	#$query .= 'UPDATE `crnrstn_params` SET `crnrstn_params`.`METHODID`="'.$tmp_crc32.'" WHERE `crnrstn_params`.`METHODID`="'.$crnrstn_method_METHODID.'";';
	#$query .= 'UPDATE `crnrstn_techspecs` SET `crnrstn_techspecs`.`METHODID`="'.$tmp_crc32.'" WHERE `crnrstn_techspecs`.`METHODID`="'.$crnrstn_method_METHODID.'";';	
	$query .= 'UPDATE `crnrstn_method` SET `crnrstn_method`.`METHODID`="'.$tmp_crc32.'" WHERE `crnrstn_method`.`METHODID`="'.$crnrstn_method_METHODID.'";';
}

//
// PROCESS MULTI QUERY TO UPDATE ALL CHECKSUMS
echo "Processing multiquery...<br>";
#echo $query;
$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);

//
// CLOSE DATABASE CONNECTION
echo "Closing database connection...<br>";
$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);

echo "Done!<br>";
?>