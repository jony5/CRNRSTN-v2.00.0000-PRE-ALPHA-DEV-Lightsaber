<?php

/* 
// J5
// Code is Poetry */
require('_crnrstn.root.inc.php');
include_once($ROOT . '_crnrstn.config.inc.php');

require($oUSER->getEnvParam('DOCUMENT_ROOT').$oUSER->getEnvParam('DOCUMENT_ROOT_DIR').'/common/inc/fh/session.inc.php');
echo "You don't want to run this...do you?<br><br><br>";

function cleanMySQLEscapes($dirtyString){
	
	echo "Clean the escapes from ".$dirtyString."<br>";
	#$string = 'The quick brown fox jumped over the lazy dog.';
	$patterns = array();
	$patterns[0] = '\&quot;';
	$patterns[1] = "\'";
//	$patterns[2] = '=';
//	$patterns[3] = '{';
//	$patterns[4] = '}';
//	$patterns[5] = '(';
//	$patterns[6] = ')';
//	$patterns[7] = ' ';
//	$patterns[8] = '	';
//	$patterns[9] = ',';
//	$patterns[10] = '\n';
//	$patterns[11] = '\r';
//	$patterns[12] = '\'';
//	$patterns[13] = '/';
//	$patterns[14] = '#';
//	$patterns[15] = ';';
//	$patterns[16] = ':';
//	$patterns[17] = '>';
	$replacements = array();
	$replacements[0] = '"';
	$replacements[1] = "'";
//	$replacements[2] = '';
//	$replacements[3] = '';
//	$replacements[4] = '';
//	$replacements[5] = '';
//	$replacements[6] = '';
//	$replacements[7] = '';
//	$replacements[8] = '';
//	$replacements[9] = '';
//	$replacements[10] = '';
//	$replacements[11] = '';
//	$replacements[12] = '';
//	$replacements[13] = '';
//	$replacements[14] = '';
//	$replacements[15] = '';
//	$replacements[16] = '';
//	$replacements[17] = '';
	
	#$str = preg_replace($patterns, $replacements, $str);
	$cleanString = str_replace($patterns, $replacements, $dirtyString);

	return $cleanString;
}


//
// ACTIVITY LOGGING
try{
	
	$queryDescript_ARRAY = array(
	'crnrstn_examples_TECHSPECID_SOURCE' => 0
	);
	
	//
	// DB/UN IN CONFIG FILE TAKES PRECEDENCE.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn00');
	$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection();

	$query = 'SELECT `crnrstn_5e36605ca11a065e8471_notes`.`EXAMPLE_RAW` FROM `crnrstn_5e36605ca11a065e8471_notes` WHERE `crnrstn_5e36605ca11a065e8471_notes`.`NOTEID_SOURCE`="f96c516ae17be37ca97c5b331b71c4e2";';
	
	$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);
	
	//
	// REMAIN STILL WHILE YOUR LIFE IS EXTRACTED
	$ROWCNT=0;
	do {
		if ($result = $mysqli->store_result()) {
			while ($row = $result->fetch_row()) {
				foreach($row as $fieldPos=>$value){
					//
					// STORE RESULT
					#echo "ROW :: ".$ROWCNT.",FIELDPOS :: ".$fieldPos.",VAL :: ".$value."<br>";
					$result_ARRAY[$ROWCNT][$fieldPos]=$value;
					
				}
				$ROWCNT++;
			}
			$result->free();
		}

		if ($mysqli->more_results()) {
			//
			// END OF RECORD. MORE TO FOLLOW.
		}
	} while ($mysqli->next_result());
	
} catch( Exception $e ) {

	//
	// LOG ERROR FOR DB ACTIVITY LOGGING
	$oENV->oLOGGER->captureNotice('CRNRSTN error notification :: mysqli query failed', LOG_NOTICE, $e->getMessage());
}

$query='';
for($rownum=0; $rownum<sizeof($result_ARRAY); $rownum++){

	$crnrstn_examples_TECHSPECID_SOURCE = $result_ARRAY[$rownum][$queryDescript_ARRAY['crnrstn_examples_TECHSPECID_SOURCE']];
	#echo 'Cleaning SQL update for '.$crnrstn_examples_TECHSPECID_SOURCE.'...<br>';
	
	//
	// CALC CHECKSUM
	#$tmp_crc32=crc32($crnrstn_examples_TECHSPECID_SOURCE);
	
	//
	// BUILD CHECKSUM UPDATE SQL
	#$query .= 'UPDATE `crnrstn_examples` SET `crnrstn_examples`.`EXAMPLEID`="'.$tmp_crc32.'" WHERE `crnrstn_examples`.`EXAMPLEID_SOURCE`="'.$crnrstn_examples_TECHSPECID_SOURCE.'" LIMIT 1;';
	$cleanString = cleanMySQLEscapes($crnrstn_examples_TECHSPECID_SOURCE);
	echo "<br><br>-- Clean string: <tectarea>".$cleanString."</textarea><br>";
}

echo "Closing connection...<br>";
$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);

die();

//
// PROCESS MULTI QUERY TO UPDATE ALL CHECKSUMS
echo "Processing multiquery...<br>";
#echo $query;
$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);

//
// CLOSE DATABASE CONNECTION
echo "Closing database connection...<br>";
$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);

echo "Done!<br>";
?>