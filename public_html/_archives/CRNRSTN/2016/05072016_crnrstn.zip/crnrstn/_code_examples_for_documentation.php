<?php
######################
# http://127.0.0.1/crnrstn/documentation/classes/cookie_manager/
# http://127.0.0.1/crnrstn/documentation/classes/cookie_manager/__construct/
# http://127.0.0.1/crnrstn/documentation/classes/cookie_manager/addcookie/
######################

//
// CRNRSTN CLASS LIBRARY
include_once('_crnrstn.config.inc.php');

//
// INSTANTIATE COOKIE MANAGER
if(!isset($oCOOKIE_MGR)){
	$oCOOKIE_MGR = new crnrstn_cookie_manager('sampleCookie','hello cookie!', time() + 1800);
}

//
// SEND COOKIE DATA TO CLIENT 
$oCOOKIE_MGR->addCookie('sampleCookie','hello cookie!', time() + 1800);


?>