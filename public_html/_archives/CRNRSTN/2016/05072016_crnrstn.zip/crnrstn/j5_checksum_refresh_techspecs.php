<?php

/* 
// J5
// Code is Poetry */
require('_crnrstn.root.inc.php');
include_once($ROOT . '_crnrstn.config.inc.php');

require($oUSER->getEnvParam('DOCUMENT_ROOT').$oUSER->getEnvParam('DOCUMENT_ROOT_DIR').'/common/inc/fh/session.inc.php');
echo "You don't want to run this...do you?<br><i>I will refresh crc32 checksums...</i><br><br>";

echo "die";
die();

//
// ACTIVITY LOGGING
try{
	
	$queryDescript_ARRAY = array(
	'crnrstn_techspecs_TECHSPECID_SOURCE' => 0
	);
	
	//
	// DB/UN IN CONFIG FILE TAKES PRECEDENCE.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn00');
	$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection();

	$query = 'SELECT `crnrstn_techspecs`.`TECHSPECID_SOURCE` FROM `crnrstn_techspecs` WHERE `crnrstn_techspecs`.`ISACTIVE`="1";';
	
	$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);
	
	//
	// REMAIN STILL WHILE YOUR LIFE IS EXTRACTED
	$ROWCNT=0;
	do {
		if ($result = $mysqli->store_result()) {
			while ($row = $result->fetch_row()) {
				foreach($row as $fieldPos=>$value){
					//
					// STORE RESULT
					#echo "ROW :: ".$ROWCNT.",FIELDPOS :: ".$fieldPos.",VAL :: ".$value."<br>";
					$result_ARRAY[$ROWCNT][$fieldPos]=$value;
					
				}
				$ROWCNT++;
			}
			$result->free();
		}

		if ($mysqli->more_results()) {
			//
			// END OF RECORD. MORE TO FOLLOW.
		}
	} while ($mysqli->next_result());
	
} catch( Exception $e ) {

	//
	// LOG ERROR FOR DB ACTIVITY LOGGING
	$oENV->oLOGGER->captureNotice('CRNRSTN error notification :: mysqli query failed', LOG_NOTICE, $e->getMessage());
}

	
$query='';
for($rownum=0; $rownum<sizeof($result_ARRAY); $rownum++){

	$crnrstn_techspecs_TECHSPECID_SOURCE = $result_ARRAY[$rownum][$queryDescript_ARRAY['crnrstn_techspecs_TECHSPECID_SOURCE']];
	echo 'Building SQL update for '.$crnrstn_techspecs_TECHSPECID_SOURCE.'...<br>';
	
	//
	// CALC CHECKSUM
	$tmp_crc32=crc32($crnrstn_techspecs_TECHSPECID_SOURCE);
	
	//
	// BUILD CHECKSUM UPDATE SQL
	$query .= 'UPDATE `crnrstn_techspecs` SET `crnrstn_techspecs`.`TECHSPECID`="'.$tmp_crc32.'" WHERE `crnrstn_techspecs`.`TECHSPECID_SOURCE`="'.$crnrstn_techspecs_TECHSPECID_SOURCE.'" LIMIT 1;';
}

//
// PROCESS MULTI QUERY TO UPDATE ALL CHECKSUMS
echo "Processing multiquery...<br>";
$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);

//
// CLOSE DATABASE CONNECTION
echo "Closing database connection...<br>";
$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);

echo "Done!<br>";
?>