<?php
/* 
// J5
// Code is Poetry */
require('_crnrstn.root.inc.php');
include_once($ROOT . '_crnrstn.config.inc.php');
//require($oUSER->getEnvParam('DOCUMENT_ROOT').$oUSER->getEnvParam('DOCUMENT_ROOT_DIR').'/common/classes/user.inc.php');
//require($oUSER->getEnvParam('DOCUMENT_ROOT').$oUSER->getEnvParam('DOCUMENT_ROOT_DIR').'/common/classes/database.inc.php');
//require($oUSER->getEnvParam('DOCUMENT_ROOT').$oUSER->getEnvParam('DOCUMENT_ROOT_DIR').'/common/inc/fh/session.inc.php');
echo "HEADERS :: ".$oENV->oHTTP_MGR->getHeaders().'<br>---<hr><br>';
echo "You don't want to run this...do you?<br><i>I am capable of dropping and recreating 120+ tables...</i><br><br>";
$uri = $_SERVER['REQUEST_URI'];
#$uri = str_replace('j5.php','',$uri);
echo $uri.'<br>';

#echo sizeof($code_elementid_ARRAY['']);
//foreach($code_elementid_ARRAY as $key=>$val){
/*
$content_array = array('1','2','3');
$tmp_array = array('hello world',420,420.123,true, false,$content_array,'goodbye!');
for($i=0;$i<sizeof($tmp_array);$i++){
	echo 'TYPE :: '.gettype($tmp_array[$i]).'| VALUE :: '.$tmp_array[$i].'| SIZEOF :: '.sizeof($tmp_array[$i]).'<br>';
	echo 'saving to session...<br>';
	$oENV->oSESSION_MGR->setSessionParam('TEST_VAL'.$i,$tmp_array[$i]);
	echo 'done saving to session...<br>';
	echo 'outputting from session...<br>';
	echo 'TYPE :: '.gettype($oENV->oSESSION_MGR->getSessionParam('TEST_VAL'.$i)).'| VALUE :: '.$oENV->oSESSION_MGR->getSessionParam('TEST_VAL'.$i).'| SIZEOF :: '.sizeof($oENV->oSESSION_MGR->getSessionParam('TEST_VAL'.$i)).'|ENCRYPT STATUS :: '.$_SESSION['CRNRSTN_ENCRYPT'.crc32('TEST_VAL'.$i)].'<br>';
	echo '===========================================<br>';
}


echo "I am done!<br><br>";
*/



	function dynInject($placeholder, $newcontent, $target){
		$patterns = array();
		$replacements = array();
		$patterns[0] = $placeholder;
		$replacements[0] = $newcontent;
		$target = preg_replace($patterns, $replacements, $target);
		#$str = str_replace($patterns, $replacements, $target);
		return $target;
	}
	
	echo dynInject('/<\/body>/', ' Got it!</body> ', 'this is the target.</body>');
//}
//die();
/*
TESTING ARRAY STORAGE IN SESSION VIA oSESSION_MGR::
$testarray = array();
$testarray[0] = 'hello world';
$testarray[1] = 'hello';

$oENV->oSESSION_MGR->setSessionParam('_CRNRSTN_SESSION_TEST', $testarray);
$_SESSION['_CRNRSTN_SESSION_TEST']=$testarray;

echo "<br>";
echo (sizeof($_SESSION['_CRNRSTN_SESSION_TEST']));
echo "<hr>";
echo (sizeof($oENV->oSESSION_MGR->getSessionParam('_CRNRSTN_SESSION_TEST')));
echo "<br>";

*/

//
// ACTIVITY LOGGING
try{
	#('LOCALHOST_PC', 'localhost', 'crnrstn_stage', 'KNUcSHWCARrZUsaZ', 'crnrstn_stage');
	#$mysqli = $oMYSQLI_CONN_MGR->returnConnection('host', 'database', 'user', 'port', 'pwd');
	//
	// GRAB DATABASE CONNECTION TO LOG ACTIVITY **[POSSIBLE ENHANCEMENT]::BREAK CREATE A database.inc.php FOR THE SITE**
	// DB NAME CACHE LAG. HOST CACHE LAG. UN CACHE LAG.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection();
	
	// HOST CACHE LAG.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost');
	
	// 
	// DB IN CONFIG FILE TAKES PRECEDENCE.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage');
	
	//
	// DB/UN IN CONFIG FILE TAKES PRECEDENCE.
	$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection();
	#$mysqli_ro = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn_stage_ro', '', 'ntasfWqP38aSrC9s');
	#$mysqli_demo = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_demo', 'crnrstn_demo');
	
	// DB/UN IN CONFIG FILE TAKES PRECEDENCE.
	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn_stage', '3306');

	#$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn_stage', '', 'KNUcSHWCARrZUsaZ');
	
	/*$query = "INSERT INTO `php_function_define` (`ACTIVITY_TYPE` , `ACTIVITY_NAME`, `SCRIPT_NAME`, `HTTP_USER_AGENT`, `HTTP_REFERER`, `HTTP_HEADERS`,
	 `REQUEST_METHOD`, `REMOTE_ADDR`) VALUES ('BROWSER_REQUEST',
	'PAGEVIEW_test_J5_IS_ALIVE','".$_SERVER['SCRIPT_NAME']."','".$_SERVER['HTTP_USER_AGENT']."','".$_SERVER['HTTP_REFERER']."','".addslashes($oENV->oHTTP_MGR->getHeaders())."','".$_SERVER['REQUEST_METHOD']."','".$_SERVER['REMOTE_ADDR']."');";
	
	$query1 = 'SELECT `code_element_define`.`ELEMENTID_SOURCE`, `code_element_define`.`NAME`, `code_element_define`.`RELATED_FUNC_LIST`
					FROM `code_element_define` WHERE `code_element_define`.`PHP_VERSION`="";';
	*/
	
	$tbl = 'crnrstn_class';
	$sourcekey = 'CLASSID_SOURCE';
	$query = 'SELECT `'.$tbl.'`.`'.$sourcekey.'`
	FROM `'.$tbl.'`
	WHERE `'.$tbl.'`.`ISACTIVE`="1";';
	
//	$tbl = 'crnrstn_class';
//	$sourcekey = 'CLASSID_SOURCE';
//	$query = 'SELECT `'.$tbl.'`.`'.$sourcekey.'`, `'.$tbl.'`.`PAGE_ELEMENT_URI`
//	FROM `'.$tbl.'`
//	WHERE `'.$tbl.'`.`ISACTIVE`="1";';
	
	$query .= 'SELECT `crnrstn_method`.`METHODID_SOURCE` 
	FROM `crnrstn_method`
	WHERE `crnrstn_method`.`ISACTIVE`="1";
	';
	
	$query .= 'TRUNCATE TABLE `user_notes`;';
	$query .= 'TRUNCATE TABLE `crnrstn_ugc_search`;';

/*	#$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);
	echo '<br><br>'.$query.'<br><br>';
	$result = $oENV->oMYSQLI_CONN_MGR->processQuery($mysqli, $query);
	#$result1 = $oENV->oMYSQLI_CONN_MGR->processQuery($mysqli_demo, $query);
	printf("Select returned %d rows.\n", $result->num_rows);
	$row = $result->fetch_all(MYSQLI_NUM);
	
	$query='';
	foreach($row as $key=>$val){
		$tmp_uri = uri_rootSanitize($val[1]);
		#echo 'value :: '.$val[0].' :: '.$tmp_uri.'<br>';
		$query .= 'UPDATE `'.$tbl.'` SET `'.$tbl.'`.`URI` = "'.$tmp_uri.'" WHERE `'.$tbl.'`.`'.$sourcekey.'`="'.$val[0].'" LIMIT 1;';
		#echo $query.'<br>';
	}*/
	
	$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query);

	//
	// REMAIN STILL WHILE YOUR LIFE IS EXTRACTED
	$ROWCNT=0;
	do {
		if ($result = $mysqli->store_result()) {
			while ($row = $result->fetch_row()) {
				foreach($row as $fieldPos=>$value){
					//
					// STORE RESULT
					echo "ROW :: ".$ROWCNT.",FIELDPOS :: ".$fieldPos.",VAL :: ".$value."<br>";
					$result_ARRAY[$ROWCNT][$fieldPos]=$value;
					
				}
				$ROWCNT++;
			}
			$result->free();
		}

		if ($mysqli->more_results()) {
			//
			// END OF RECORD. MORE TO FOLLOW.
		}
	} while ($mysqli->next_result());
	
	#$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);
	//$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli_ro);
	//$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli_demo);
	
} catch( Exception $e ) {

	//
	// LOG ERROR FOR DB ACTIVITY LOGGING
	$oENV->oLOGGER->captureNotice('CRNRSTN error notification :: mysqli query failed', LOG_NOTICE, $e->getMessage());
}
//$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);
//die();
//echo '<br><hr><a href="http://127.0.0.1/crnrstn/__total_purge.php" target="_self">[total purge]</a>';

//$query='';
//$mysqli = $oENV->oMYSQLI_CONN_MGR->returnConnection('localhost', 'crnrstn_stage', 'crnrstn_stage');
//$ts = date("Y-m-d H:i:s", time()-60*60*6);
for($i=0; $i<sizeof($result_ARRAY); $i++){
//for($i=0; $i<2; $i++){
	//
	// CUSTOM HASH TESTING
//	$seednum = microtime().rand();
//	$seednum_full = md5($seednum);
//	$seednum_mini = substr($seednum_full,1,20);
	
//	$seed_ARRAY[$seednum_mini] = 1;
	

  //$elemTypeID_SOURCE = 'PHP_NATIVE_METHOD';

//$query .= 'UPDATE `code_element_define` SET 
//			`ELEMENTID`="'.crc32($seednum_mini).'",
//			`ELEMENTID_SOURCE`="'.$seednum_mini.'",
//			`ELEM_TYPEID`="'.crc32($elemTypeID_SOURCE).'",
//			`ELEM_TYPEID_SOURCE`="'.$elemTypeID_SOURCE.'",
//			`DATEMODIFIED`="'.$ts.'" WHERE 
//			`ID`="'.$result_ARRAY[$i][0].'" LIMIT 1;';

$query_dyntbl .= "
	DROP TABLE IF EXISTS `crnrstn_".$result_ARRAY[$i][0]."_notes`;
	CREATE TABLE IF NOT EXISTS `crnrstn_".$result_ARRAY[$i][0]."_notes` (
  `NOTEID_SOURCE` char(32) NOT NULL,
  `NOTEID_CRC32` bigint(11) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `USERNAME_CRC32` bigint(11) NOT NULL,
  `ISACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  `REPLYTO_NOTEID` char(32) NOT NULL,
  `SUBJECT` varchar(200) NOT NULL,
  `NOTE_STYLED` blob NOT NULL,
  `NOTE_RAW` blob NOT NULL,
  `NOTE_ELEM_TT` blob NOT NULL,
  `NOTE_BACKLOG` tinyint(1) NOT NULL,
  `CNT_LIKES` int(11) NOT NULL,
  `CNT_REPLIES` int(11) NOT NULL,
  `STYLED_CHAR_CNT` int(11) NOT NULL,
  `RAW_CHAR_CNT` int(11) NOT NULL,
  `LANGCODE` char(2) NOT NULL DEFAULT 'EN',
  `DATEMODIFIED` datetime NOT NULL,
  `DATECREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`NOTEID_SOURCE`),
  KEY `NOTEID_CRC32` (`NOTEID_CRC32`,`USERNAME`,`USERNAME_CRC32`,`ISACTIVE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CLASS/METHOD SPECIFIC NOTES ::';
";

$query_dyntbl .= "
	DROP TABLE IF EXISTS `crnrstn_".$result_ARRAY[$i][0]."_notes_publish`;
	CREATE TABLE IF NOT EXISTS `crnrstn_".$result_ARRAY[$i][0]."_notes_publish` (
  `NOTEID_SOURCE` char(32) NOT NULL,
  `NOTEID_CRC32` bigint(11) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `USERNAME_CRC32` bigint(11) NOT NULL,
  `ISACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  `REPLYTO_NOTEID` char(32) NOT NULL,
  `SUBJECT` varchar(200) NOT NULL,
  `NOTE_STYLED` blob NOT NULL,
  `NOTE_RAW` blob NOT NULL,
  `NOTE_ELEM_TT` blob NOT NULL,
  `NOTE_BACKLOG` tinyint(1) NOT NULL,
  `CNT_LIKES` int(11) NOT NULL,
  `CNT_REPLIES` int(11) NOT NULL,
  `STYLED_CHAR_CNT` int(11) NOT NULL,
  `RAW_CHAR_CNT` int(11) NOT NULL,
  `LANGCODE` char(2) NOT NULL DEFAULT 'EN',
  `DATEMODIFIED` datetime NOT NULL,
  `DATECREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`NOTEID_SOURCE`),
  KEY `NOTEID_CRC32` (`NOTEID_CRC32`,`USERNAME`,`USERNAME_CRC32`,`ISACTIVE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CLASS/METHOD SPECIFIC PUBLISHED NOTES ::';
";

$query_dyntbl .= "
DROP TABLE IF EXISTS `crnrstn_".$result_ARRAY[$i][0]."_likes`;
CREATE TABLE IF NOT EXISTS `crnrstn_".$result_ARRAY[$i][0]."_likes` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `NOTEID_SOURCE` char(32) NOT NULL,
  `NOTEID_CRC32` bigint(11) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `USERNAME_CRC32` bigint(11) NOT NULL,
  `ISACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  `DATEMODIFIED` datetime NOT NULL,
  `DATECREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `NOTEID_SOURCE` (`NOTEID_SOURCE`,`NOTEID_CRC32`,`USERNAME`,`USERNAME_CRC32`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CLASS/METHOD SPECIFIC LIKES ::' AUTO_INCREMENT=1 ;
";

$query_dyntbl .= "
	DROP TABLE IF EXISTS `crnrstn_".$result_ARRAY[$i][0]."_users`;
	CREATE TABLE IF NOT EXISTS `crnrstn_".$result_ARRAY[$i][0]."_users` (
	  `USERNAME` varchar(100) NOT NULL,
	  `USERID_SOURCE` char(32) NOT NULL,
	  `USERNAME_CRC32` bigint(11) NOT NULL,
	  `USERID` bigint(11) NOT NULL,
	  `ISACTIVE` tinyint(1) NOT NULL DEFAULT '1',
	  `USERNAME_DISPLAY` varchar(100) NOT NULL,
	  `LANGCODE` char(2) NOT NULL DEFAULT 'EN',
	  `IMAGE_NAME` char(65) NOT NULL DEFAULT 'default.jpg',
	  `IMAGE_WIDTH` int(11) NOT NULL DEFAULT '64',
	  `IMAGE_HEIGHT` int(11) NOT NULL DEFAULT '64',
	  `EXTERNAL_URI_FORMATTED` blob NOT NULL,
	  `DATEMODIFIED` datetime NOT NULL,
	  `DATECREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  PRIMARY KEY (`USERNAME`),
	  UNIQUE KEY `USERID_SOURCE` (`USERID_SOURCE`),
	  KEY `USERNAME_CRC32` (`USERNAME_CRC32`,`USERID`,`ISACTIVE`)
	) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CLASS/METHOD SPECIFIC USERS ::';

";


//
echo 'Building query for HASH Value :: '.$result_ARRAY[$i][0].'<br>';



//echo 'ID::('.$result_ARRAY[$i][0].') <strong>'.$seednum_mini.'</strong> :: <strong>'.crc32($seednum_mini).'</strong> :: COUNT TOTAL('.($i+1).') :: COUNT UNIQUE('.sizeof($seed_ARRAY).')<br>';

//echo '<a href="http://127.0.0.1/crnrstn/admin/mgmt/_frms/function_edit.php?f='.$result_ARRAY[$i][0].'" target="_blank">'.$result_ARRAY[$i][1].'</a> - '.$result_ARRAY[$i][2].'<br>';
	
}



$result = $oENV->oMYSQLI_CONN_MGR->processMultiQuery($mysqli, $query_dyntbl);
$oENV->oMYSQLI_CONN_MGR->closeConnection($mysqli);

function uri_rootSanitize($str){
	$patterns = array();
	$patterns[0] = 'crnrstn.jony5.com';
	#$patterns[1] = '../../../classes';
	$replacements = array();
	$replacements[0] = 'crnrstn';
	#$replacements[1] = '../documentation/classes';
	
	$str = str_replace($patterns, $replacements, $str);
	return $str;
}


?>