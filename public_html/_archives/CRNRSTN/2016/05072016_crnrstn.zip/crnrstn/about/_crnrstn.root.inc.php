<?php
/* 
// J5
// Code is Poetry */

$ROOT="../";
?>