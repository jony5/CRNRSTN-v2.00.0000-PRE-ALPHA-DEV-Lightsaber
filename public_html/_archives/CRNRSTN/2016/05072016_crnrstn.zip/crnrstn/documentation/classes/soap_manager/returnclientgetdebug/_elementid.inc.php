<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="0d6a0c99e05ef4829edf";
?>