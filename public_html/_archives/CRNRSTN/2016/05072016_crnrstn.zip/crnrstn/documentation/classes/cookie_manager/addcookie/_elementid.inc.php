<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="c02242defb7960f61258";
?>