<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="480372eec3711de660d9";
?>