<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="258a3bb3585d569b8d79";
?>