<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="feac321d3c5aa49417b5";
?>