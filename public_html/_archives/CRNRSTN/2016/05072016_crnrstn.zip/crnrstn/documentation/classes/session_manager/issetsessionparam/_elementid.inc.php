<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="54b3a238e2da6c394429";
?>