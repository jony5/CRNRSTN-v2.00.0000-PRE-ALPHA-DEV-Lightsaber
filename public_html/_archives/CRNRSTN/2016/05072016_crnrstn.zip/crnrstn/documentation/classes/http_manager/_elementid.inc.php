<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="21ea3b29a98e1b6bfa55";
?>