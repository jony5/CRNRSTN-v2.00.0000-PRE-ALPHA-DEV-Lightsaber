<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="1247265f28e5ac616c23";
?>