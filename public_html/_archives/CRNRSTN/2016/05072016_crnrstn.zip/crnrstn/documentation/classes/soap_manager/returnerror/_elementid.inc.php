<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="11afa26d09a7d6bc3f8f";
?>