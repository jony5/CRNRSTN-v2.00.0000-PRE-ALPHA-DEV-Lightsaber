<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="80096a95a930ac5ae547";
?>