<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="8fe547e1a016acdc23b7";
?>