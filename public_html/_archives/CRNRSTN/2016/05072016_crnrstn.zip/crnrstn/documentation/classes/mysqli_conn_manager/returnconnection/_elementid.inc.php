<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="6d0d2e1ee0024980f06a";
?>