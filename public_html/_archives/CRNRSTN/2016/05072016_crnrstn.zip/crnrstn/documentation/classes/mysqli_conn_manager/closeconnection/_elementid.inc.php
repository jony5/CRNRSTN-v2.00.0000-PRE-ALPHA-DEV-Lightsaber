<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="6c37cad77eccac86be6f";
?>