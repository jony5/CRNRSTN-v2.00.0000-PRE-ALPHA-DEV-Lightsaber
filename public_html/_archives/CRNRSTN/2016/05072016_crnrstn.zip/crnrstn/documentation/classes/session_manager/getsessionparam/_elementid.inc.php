<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="82cac5ec76b55cdb2593";
?>