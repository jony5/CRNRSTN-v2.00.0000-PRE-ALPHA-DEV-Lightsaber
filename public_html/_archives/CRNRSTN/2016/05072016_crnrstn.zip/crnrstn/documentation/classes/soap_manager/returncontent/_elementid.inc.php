<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="dd8203d609bf31e952a8";
?>