<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="cbc68bc15cda70c0e223";
?>