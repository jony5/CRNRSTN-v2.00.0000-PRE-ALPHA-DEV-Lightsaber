<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="c929e1bc30c959538a38";
?>