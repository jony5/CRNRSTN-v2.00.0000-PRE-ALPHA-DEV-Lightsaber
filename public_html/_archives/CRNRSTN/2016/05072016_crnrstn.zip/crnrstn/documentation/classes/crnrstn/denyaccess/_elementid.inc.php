<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="177947bfdbac40fb4111";
?>