<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="2d1a38e86297a20ab3a0";
?>