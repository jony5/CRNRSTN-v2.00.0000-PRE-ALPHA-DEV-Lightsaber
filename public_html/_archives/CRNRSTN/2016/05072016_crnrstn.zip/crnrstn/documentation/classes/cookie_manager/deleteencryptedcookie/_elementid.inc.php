<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="697eb81ded38667245d6";
?>