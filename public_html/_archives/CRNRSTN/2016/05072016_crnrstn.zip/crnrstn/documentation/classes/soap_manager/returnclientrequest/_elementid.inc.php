<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="1777a53f666dfc67844c";
?>