<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="2f2729737ae3dc9702e4";
?>