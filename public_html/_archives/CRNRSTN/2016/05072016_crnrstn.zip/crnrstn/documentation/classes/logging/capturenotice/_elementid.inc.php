<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="bc19830456ee4f25a37b";
?>