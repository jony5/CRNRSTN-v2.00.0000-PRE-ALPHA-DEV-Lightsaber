<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="a6c96b6e30643a75181c";
?>