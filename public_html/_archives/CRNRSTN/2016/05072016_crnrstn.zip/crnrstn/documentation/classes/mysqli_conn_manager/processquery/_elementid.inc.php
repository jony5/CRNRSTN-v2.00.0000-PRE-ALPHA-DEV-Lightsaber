<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="f86f6d9e6cc18b1bbdbc";
?>