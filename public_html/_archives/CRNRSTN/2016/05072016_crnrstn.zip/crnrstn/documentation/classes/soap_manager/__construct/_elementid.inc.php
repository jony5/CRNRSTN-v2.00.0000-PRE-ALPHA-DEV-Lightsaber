<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="e79885213d5664224fc2";
?>