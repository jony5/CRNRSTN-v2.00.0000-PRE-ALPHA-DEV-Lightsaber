<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="65d5fb115a9f6a3e0b23";
?>