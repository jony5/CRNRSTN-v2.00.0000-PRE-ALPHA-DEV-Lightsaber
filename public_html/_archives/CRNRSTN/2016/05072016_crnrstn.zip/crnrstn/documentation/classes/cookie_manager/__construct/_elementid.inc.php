<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="78c21ae28daffea44df4";
?>