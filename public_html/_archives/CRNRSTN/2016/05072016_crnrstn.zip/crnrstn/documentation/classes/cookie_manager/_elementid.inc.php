<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="227e8e40a88e856caa9a";
?>