<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="77e68596c15c53c2a33a";
?>