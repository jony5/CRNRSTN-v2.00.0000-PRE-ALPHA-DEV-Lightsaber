<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="804f94e16ba5b680e239";
?>