<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="c4c166a189bb40532bee";
?>