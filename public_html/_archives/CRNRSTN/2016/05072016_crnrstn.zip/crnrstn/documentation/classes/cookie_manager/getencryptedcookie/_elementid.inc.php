<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="689d814c7a85db3b8208";
?>