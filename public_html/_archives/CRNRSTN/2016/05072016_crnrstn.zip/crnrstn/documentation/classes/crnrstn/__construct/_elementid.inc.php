<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="5e36605ca11a065e8471";
?>