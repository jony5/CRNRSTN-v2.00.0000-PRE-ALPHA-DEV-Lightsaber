<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="edb75382242def43b5a9";
?>