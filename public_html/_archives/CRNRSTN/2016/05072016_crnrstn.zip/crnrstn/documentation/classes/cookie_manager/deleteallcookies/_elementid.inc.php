<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="7d9075d36a21c23c11e5";
?>