<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="d43b081546426d29c1de";
?>