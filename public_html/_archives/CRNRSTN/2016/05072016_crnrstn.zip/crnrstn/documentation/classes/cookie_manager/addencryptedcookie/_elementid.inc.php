<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="af45de9c076c169f4aca";
?>