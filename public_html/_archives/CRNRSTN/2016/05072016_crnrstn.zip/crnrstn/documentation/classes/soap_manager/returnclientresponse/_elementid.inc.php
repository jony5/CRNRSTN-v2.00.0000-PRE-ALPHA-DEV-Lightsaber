<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="702b2f7923335341ad37";
?>