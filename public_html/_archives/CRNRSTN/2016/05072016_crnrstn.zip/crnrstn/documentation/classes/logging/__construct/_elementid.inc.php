<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="5672ed1ca86726b93ab1";
?>