<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="a28873cba28b280a5d01";
?>