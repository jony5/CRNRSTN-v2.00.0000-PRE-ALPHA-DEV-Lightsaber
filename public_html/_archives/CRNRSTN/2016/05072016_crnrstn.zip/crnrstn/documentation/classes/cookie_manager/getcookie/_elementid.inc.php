<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="39f09de995657d602158";
?>