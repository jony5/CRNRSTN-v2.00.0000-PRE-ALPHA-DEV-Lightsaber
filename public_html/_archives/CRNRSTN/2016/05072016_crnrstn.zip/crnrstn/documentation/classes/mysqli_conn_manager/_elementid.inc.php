<?php
/* 
// J5
// Code is Poetry */

$oUSER->classID_SOURCE="ba3eb7c0586b8949fd53";
?>