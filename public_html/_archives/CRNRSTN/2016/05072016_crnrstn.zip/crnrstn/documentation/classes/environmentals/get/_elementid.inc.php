<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="431d70133ef6cf688bc4";
?>