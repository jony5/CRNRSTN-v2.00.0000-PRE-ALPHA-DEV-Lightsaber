<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="09aa4eb2937b2b081c68";
?>