<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="3a115cbd6f4788924537";
?>