<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="737a8a7409eef3779d66";
?>