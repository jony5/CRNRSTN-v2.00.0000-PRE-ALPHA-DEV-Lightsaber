<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="9bde12136ca1b57c1506";
?>