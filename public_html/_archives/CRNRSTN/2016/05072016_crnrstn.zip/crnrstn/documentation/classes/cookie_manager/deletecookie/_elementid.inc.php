<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="0644826ce63fba81fa03";
?>