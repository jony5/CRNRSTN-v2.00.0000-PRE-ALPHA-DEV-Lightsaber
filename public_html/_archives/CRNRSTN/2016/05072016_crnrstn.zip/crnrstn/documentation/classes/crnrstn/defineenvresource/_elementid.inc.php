<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="8a3541328deb219f04ad";
?>