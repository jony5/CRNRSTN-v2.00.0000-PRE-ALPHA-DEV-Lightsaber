<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="80095e4417d366829202";
?>