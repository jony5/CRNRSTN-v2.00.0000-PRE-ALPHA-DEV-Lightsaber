<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="f21d0c97db2e27e13572";
?>