<?php
/* 
// J5
// Code is Poetry */

$oUSER->methodID_SOURCE="5e36605ca11a065e8471";
#$oUSER->classID_SOURCE="c929e1bc30c959538a38";
?>