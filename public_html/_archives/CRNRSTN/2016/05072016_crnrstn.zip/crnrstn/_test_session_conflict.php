<?php

/* 
// J5
// Code is Poetry */
require('_crnrstn.root.inc.php');
include_once($ROOT . '_crnrstn.config.inc.php');


//
// ECHO SESSION PARAMETER
echo "CRNRSTN DOCUMENT_ROOT";
echo $oUSER->getEnvParam('DOCUMENT_ROOT')." == ".$oUSER->getEnvParam('APP_NAME')."<br><br>";
echo "-->".$oENV->get('DOCUMENT_ROOT')."<br><br>";
//
// TEST DB CONNECTIVITY
$oUSER->testCrnrstn();

//
// TEST SESSION PARAM SET
$oENV->oSESSION_MGR->setSessionParam('FORM_UN', 'j00000101');
$tmp_val = $oENV->oSESSION_MGR->getSessionParam('FORM_UN');
echo $tmp_val."<br><br>";

echo '<a href="../jony5/_test_session_conflict.php">jony5</a>';
?>