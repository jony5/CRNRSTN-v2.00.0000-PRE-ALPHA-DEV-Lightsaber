/*
File:			input_Filter.h
Programmer:		Jonathan Harris
Last Modified:	11.29.2002
Description:	Take user input from menu decisiona and convert to proper integer for decision.
*/


#ifndef INPUT_FILTER_H
#define INPUT_FILTER_H

class input_Filter {
public:
	input_Filter();
	~input_Filter();
	void receive_Input();			// receive user input and store in selection
	int input_Compare();			// take selection and convert it to an integer
	void test_Output(int);

private:
	char *selection;
	int menu_Choice;



};

#endif

