/*
File:				enemy_Force.cpp
Programmer:			Jonathan Harris
Last Modified:		11.24.2002
Description:		Enemy base class member definitions for SAM and fighter..
*/
#include "enemy_Force.h"


enemy_Force::enemy_Force(int num_Flare, int num_Chaff, int num_Aim, int num_Side){}

enemy_Force::~enemy_Force(){}

