/*
File:			noSelection_Found.h
Programmer:		Jonathan Harris
Last Modified:	12.6.2002
Description:	This is my exception class.
*/


#ifndef NOSELECTION_FOUND
#define NOSELECTION_FOUND
#include<iostream.h>
	//*********************EXCEPTION HANDLING FUNCTION************************
class noSelection_Found {
public:
	noSelection_Found();
	problem();
private:
//        NONE

};

#endif