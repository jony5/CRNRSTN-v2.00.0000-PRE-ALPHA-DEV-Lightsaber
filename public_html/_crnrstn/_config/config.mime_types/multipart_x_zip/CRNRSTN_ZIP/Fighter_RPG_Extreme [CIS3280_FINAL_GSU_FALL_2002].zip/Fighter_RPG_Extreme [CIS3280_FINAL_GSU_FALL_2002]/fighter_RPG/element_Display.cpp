/*
File:			element_Display.cpp
Programmer:		Jonathan Harris
Date:			11.30.2002
Description:	Member functions that display elements...
*/

#include <string.h>
#include <ctype.h>
#include <fstream.h>
#include <iostream.h>
#include <stdlib.h>
#include "element_Display.h"

element_Display::element_Display(){}			// Constructor

element_Display::~element_Display(){}			// Destructor

void element_Display::instructions()
{
	char pixel;

	fstream infile;
	infile.open("maintenance\\RPG_instructions.txt",ios::in);

		while((pixel = infile.get()) != EOF)			// read from file until reach end
			cout << pixel;
	
		cout  << "\n\t\tPress RETURN to continue.\n";
		pixel = cin.get();
		do											// request return to continue
		{
			pixel = cin.get();
			if(pixel != '\n')
				{
					cin.ignore(75,'\n');
				}
		}while(pixel !='\n');

	infile.close();
}
//****************************************************
//****************************************************
void element_Display::scene_1()
{
	char pixel;

	fstream infile;
	infile.open("scenarios\\base_Scene.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;
	
	cout  << "\n\t\tPress RETURN to continue.\n";
	do											// request return to continue
	{
		pixel = cin.get();
		if(pixel != '\n')
			{
				cin.ignore(75,'\n');
			}
	}while(pixel !='\n');
	infile.close();
}


//****************************************************
//****************************************************
void element_Display::scene_2()
{

	char pixel;

	fstream infile;
	infile.open("scenarios\\briefing.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	cout  << "\n\t\tPress RETURN to continue.\n";
	pixel = cin.get();
	do											// request return to continue
	{
		pixel = cin.get();
		if(pixel != '\n')
			{
				cin.ignore(75,'\n');
			}
	}while(pixel !='\n');
	infile.close();
}

//****************************************************
//****************************************************
void element_Display::menu_2()				// item select or game start menu
{
	char pixel;

	fstream infile;
	infile.open("menus\\opening_Menu.txt",ios::in);

	if(!infile)									// standard form of error checking for this?  Try loop not necessary
	{
		cerr << "File \"menus\\opening_Menu.txt\" could not be found."<< endl;		// I hope this works...test it.
		exit(1);
	}
	
	while((pixel = infile.get()) != EOF){		// read from file until reach end
		cout << pixel;
	}
	infile.seekg(0);
	infile.close();
}

//****************************************************
//****************************************************
void element_Display::menu_3()	 			// add items 
{
	char pixel;

	fstream infile;
	infile.open("menus\\add_Arms.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}


//****************************************************
//****************************************************
void element_Display::menu_4()				// remove items
{
	char pixel;

	fstream infile;
	infile.open("menus\\remove_Arms.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}


//****************************************************
//****************************************************
void element_Display::menu_5()				// remove items
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\menu_Base.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

//	do											// request return to continue
//	{
//		pixel = cin.get();
//		if(pixel != '\n')
//			{
//				cin.ignore(75,'\n');
//			}
//	}while(pixel !='\n');
	infile.close();
}

//****************************************************
//****************************************************
void element_Display::menu_6()				// south/exit
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\menu_Climb_1.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}

//****************************************************
//****************************************************
void element_Display::menu_7()				// attack menu...east or west
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\attack_Menu_1.txt",ios::in);//attack_Menu_1.txt
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}

//****************************************************
//****************************************************
void element_Display::menu_8()				// go west/exit
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\west_Menu.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}

//****************************************************
//****************************************************

void element_Display::menu_9()				// east or exit
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\east_Exit.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}


//****************************************************
//****************************************************
void element_Display::menu_10()				// north or exit
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\north_Menu.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}


//****************************************************
//****************************************************
void element_Display::attack_Choices()			// attack!! attack!!
{
	char pixel;

	fstream infile;
	infile.open("menus\\game_Sequence\\attack_Attack.txt",ios::in|ios::nocreate);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}


//****************************************************
//****************************************************
void element_Display::game_Over()				// THE END
{
	char pixel;

	fstream infile;
	infile.open("scenarios\\game_Over.txt",ios::in);
	
	while((pixel = infile.get()) != EOF)		// read from file until reach end
		cout << pixel;

	infile.close();
}