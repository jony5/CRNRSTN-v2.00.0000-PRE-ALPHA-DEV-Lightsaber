/*
File:			element_Display.h
Programmer:		Jonathan Harris
Date:			11.30.2002
Description:	Object that accesses menus/scenes from files...
*/


//#include "input_Filter.h"
#ifndef ELEMENT_DISPLAY_H
#define ELEMENT_DISPLAY_H

class element_Display {//: public input_Filter { //  publically inherits from input_Filter
public:										//...and so gets access to private data like "selection"
	element_Display();			// constructor
	~element_Display();			// destructor
	void attack_Choices();			// Attack!! Attack!!...menu
	void game_Over();			// GAME OVER
	void instructions();		// display menu 1
	void menu_2();				// display menu 2
	void menu_3();				// display menu 3...elements to add
	void menu_4();				// elements to remove menu
	void menu_5();				// base take-off menu
	void menu_6();
	void menu_7();
	void menu_8();
	void menu_9();
	void menu_10();
	void menu_11();
	void menu_12();
	void menu_13();
	void scene_1();				// display scene 1
	void scene_2();				// display scene 2
	void scene_3();				// display scene 3
	void scene_4();
	void scene_5();					
	void scene_6();
//	scene_7();
//	scene_8();
//	scene_9();
};
#endif