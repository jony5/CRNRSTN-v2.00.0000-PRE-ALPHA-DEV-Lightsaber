/*
File:				player_1.h
Programmer:			Jonathan Harris
Last Modified:		11.24.2002
Description:		This may be an attempt at a base class for a player.
*/

#ifndef PLAYER_1_H
#define PLAYER_1_H
#include <fstream.h>

class player_1 {
public:
	player_1();
	~player_1();
	void zero_Screen();						// to adjust screen size
	void clear_Screen_Return();				// clear display screen and await return
	void clear_Screen();					// clear screen and no wait for return
	void title_Screen();					// Display game title page
	void show_Jet();						// display jet picture
	void program_Opening_Menu();			// give user the option to skip instruction
	void instructions();					// display instructions
	void enter_Name();	// receive name of player...write to file
//	void enter_Selection();					// receive user
	void display_Full_Name();
//	void ghost_Display();					// send decisions to player's file
	void clear_File();
	void save_File();						// option to save game to floppy at game end

//	void display_Position() const;			// command to display map from file

private:
	double avaliable_Weight;					// variable to store weapon weight
	int num_Flare;
	int num_Chaff;
	int num_Aim;
	int num_Sidewinder;

	char pix;								// char var for file display
	char title[30];							// char ptr to point to player title 1st letter
	char name[30];								// char ptr to point to player name 1st letter
	fstream player_File;					// handle to access player data file
};
#endif