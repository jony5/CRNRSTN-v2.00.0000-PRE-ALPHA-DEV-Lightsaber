/*
File:				input_Filter.cpp
Programmer:			Jonathan Harris
Last Modified:		11.29.2002
Description:		Member function definitions for input_Filter.
*/

#include "noSelection_Found.h"
#include "input_Filter.h"
#include <cassert>
#include <string.h>
#include <ctype.h>
#include <fstream.h>
#include <iostream.h>
#include <stdlib.h>


input_Filter::input_Filter(){}

input_Filter::~input_Filter()
{
	delete [] selection;
}

//******************************************************
//******************************************************

void input_Filter::receive_Input()
{
	char c[20];
	cin  >> c;
	selection = new char[strlen (c) + 1];
	assert (selection != 0 );
	strcpy(selection, c);
}

void input_Filter::test_Output(int i){
	
	if(i == 16)
		throw noSelection_Found();
}

int input_Filter::input_Compare()
{
	const int options = 16;
	int i = 0, error = 0;
	const char *possible_Choices[options] = {"ADD", "REMOVE", "BEGIN", "EXIT", "SHOW", "SKIP", 
		"FLARE", "CHAFF", "SIDE", "AIM", "SOUTH", "EAST", "CLIMB", "PEE", "WEST", "NORTH"};     // 0 -> 15 + '\n' = 16
	do
	{
		while(i < options)
		{
			try{
				if ((stricmp(selection, possible_Choices[i])) != 0){
					i++;
					test_Output(i);
				}
				else
				{

					return i;
				}
					


				}
			catch (noSelection_Found input_Error) {					// exception handler
				input_Error.problem();

			}
		}

		
	
		if(i == 16 && error < 3)
		{
			delete [] selection;
			char c[20];
			cin  >> c;
			selection = new char[strlen (c) + 1];
			assert (selection != 0 );
			strcpy(selection, c);
			i = 0;
			error++;
		}
		if (error == 3)
			{
				cout << "Thanks for playing Fighter RPG!" << endl;
				exit(0);
			}
		
	}while(error < 3);

}
