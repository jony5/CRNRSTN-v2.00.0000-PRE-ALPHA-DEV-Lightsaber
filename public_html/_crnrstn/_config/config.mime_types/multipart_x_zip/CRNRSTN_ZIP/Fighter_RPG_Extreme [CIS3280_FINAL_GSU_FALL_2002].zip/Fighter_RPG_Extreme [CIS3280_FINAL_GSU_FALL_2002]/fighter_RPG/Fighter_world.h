/*
File:			fighter_World.h
Programmer:		Jonathan Harris
Last Modified:	11.22.2002
Description:	This headr file is for a sef-referential data structure which may contain my entire game...I hope this
				works...:-)
*/

#ifndef FIGHTER_WORLD_H
#define FIGHTER_WORLD_H

class Zone {
public:
	Zone( int );
	void set_Data( int );
	int get_Data() const;
	const Zone *get_NextPtr() const;

private:
	int data;
	Zone *nextPtr;				// Points to following node 
	Zone *prevPtr;				// Points to previos Node
	Zone *endPtr;				// Points to last Node
	Zone *startPtr;				// Points to first Node


};
#endif