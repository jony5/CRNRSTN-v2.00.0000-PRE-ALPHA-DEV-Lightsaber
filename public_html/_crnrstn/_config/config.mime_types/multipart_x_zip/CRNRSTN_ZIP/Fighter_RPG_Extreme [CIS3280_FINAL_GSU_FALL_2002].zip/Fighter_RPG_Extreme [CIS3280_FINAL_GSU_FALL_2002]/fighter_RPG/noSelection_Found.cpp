#include "noSelection_Found.h"


noSelection_Found::noSelection_Found()
{
//	cout <<"Please re-enter your selection carefully: ";
}

noSelection_Found::problem()
{
	cout <<"Please re-enter your selection carefully: ";
}
