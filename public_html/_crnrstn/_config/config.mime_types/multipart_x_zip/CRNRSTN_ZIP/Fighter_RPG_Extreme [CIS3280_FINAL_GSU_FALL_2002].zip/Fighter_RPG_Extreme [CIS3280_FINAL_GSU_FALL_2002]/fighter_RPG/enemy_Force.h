/*
File:				enemy_Force.h
Programmer:			Jonathan Harris
Last Modified:		11.24.2002
Description:		Enemy base class for SAM and fighter..
*/

#ifndef ENEMY_FORCE_H
#define ENEMY_FORCE_H

class enemy_Force {
public:
	enemy_Force(int, int, int, int);			// every enemy has capacity to hold weapons...
	~enemy_Force();
	virtual int fire_Item(int) const = 0;	// return status of ability to fire item...means it did fire it
										//...if false...no item left..die
										//...if true = fire item...minus one from arsenal
private:
	int num_Flare, num_Chaff, num_Aim, num_Side;			// store quantity of items
};

#endif


/*
private:
	struct bandit1_Arsenal{				// enemy 1 arsenal
		int Flare = 2;
		int Chaff;
		int Aim_120;
		int side_Winder = 5;
	};
	struct bandit2_Arsenal{				// emeny 2 arsneal
		int Flare;
		int Chaff = 2;
		int Aim_120 = 5;
		int side_Winder;
	};
	struct bandit3_Arsenal{				// enemy 3 arsenal
		int Flare = 1;
		int Chaff = 1;
		int Aim_120;
		int side_Winder = 5;
	};

*/