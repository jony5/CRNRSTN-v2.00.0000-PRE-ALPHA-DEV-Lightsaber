/*
File:			switcher.h
Programmer:		Jonathan Harris
Last Modified:	11.25.2002
Description:	Manipulation for missiles.
*/


#ifndef SWITCHER_H
#define SWITCHER_H

class switcher {
public:
	number_1();					// choice between show instruct, skip instuct, exit game
	number_2();					// choice between add, remove, start game or exit
	number_3();					// choice between flare, chaff, side, or aim
	virtual void purchase_Item(int);

private:

};

#endif