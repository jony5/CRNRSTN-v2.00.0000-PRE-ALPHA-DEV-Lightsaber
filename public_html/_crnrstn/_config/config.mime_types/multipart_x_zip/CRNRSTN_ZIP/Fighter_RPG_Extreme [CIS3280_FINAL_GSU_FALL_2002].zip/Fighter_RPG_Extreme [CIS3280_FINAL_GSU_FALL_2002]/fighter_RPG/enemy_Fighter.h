/*
File:				enemy_Fighter.h
Programmer:			Jonathan Harris
Last Modified:		12.3.2002
Description:		Enemy base class for fighter.
*/

#ifndef ENEMY_FIGHTER_H
#define ENEMY_FIGHTER_H

class enemy_Fighter : public enemy_Force {
public:
	enemy_Fighter(int,int,int,int);		// flare,chaff,aim,sidewinder


};

// Enemy Fighter inherits variables to store weapon count
#endif
