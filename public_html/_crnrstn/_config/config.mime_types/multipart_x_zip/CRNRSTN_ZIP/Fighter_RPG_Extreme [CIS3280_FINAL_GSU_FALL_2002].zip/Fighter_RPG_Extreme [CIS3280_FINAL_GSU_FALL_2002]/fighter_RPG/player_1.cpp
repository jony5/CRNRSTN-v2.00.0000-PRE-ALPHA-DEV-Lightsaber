/*
File:				player_1.cpp
Programmer:			Jonathan Harris
Last Modified:		11.25.2002
Description:		Member function definitions for class player_1.
*/

#include <cassert>
#include <iomanip.h>
#include <stdlib.h>
#include <iostream.h>
#include <cstring>
#include <fstream.h>
#include "player_1.h"

player_1::player_1(){}

player_1::~player_1(){}
//***********************************************************
//***********************************************************
void player_1::title_Screen()
{
	ifstream picture_File;
	picture_File.open ("pictures\\jet01.txt", ios::in);

	if(!picture_File)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"jet01.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = picture_File.get()) != EOF)
		{
			cout << pix;
		}		
	picture_File.seekg(0);								//move to the beginnning of file for next read
	picture_File.close();
}
//***********************************************************
//***********************************************************
void player_1::show_Jet()
{
	ifstream picture_File;
	picture_File.open ("pictures\\jet02.txt", ios::in);

	if(!picture_File)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"pictures\\jet02.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = picture_File.get()) != EOF)
		{
			cout << pix;
		}		
	picture_File.seekg(0);								//move to the beginnning of file for next read
	picture_File.close();
}
//***********************************************************
//***********************************************************
void player_1::program_Opening_Menu()
{
	ifstream pre_Menu;
	cout << " Please make a selection from the following menu." << endl;
	pre_Menu.open ("menus\\pre_Game_Menu.txt", ios::in);

	if(!pre_Menu)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"menus\\pre_Game_Menu.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = pre_Menu.get()) != EOF)
		{
			cout << pix;
		}		
	pre_Menu.seekg(0);								//move to the beginnning of file for next read
	pre_Menu.close();
}
//***********************************************************
//***********************************************************

void player_1::instructions()							// function to read from file containing plane picture
{
	ifstream instruction_File;
	instruction_File.open ("maintenance\\RPG_instructions.txt", ios::in);

	if(!instruction_File)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"RPG_instructions.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = instruction_File.get()) != EOF)
		{
			cout << pix;
		}		
	instruction_File.seekg(0);								//move to the beginnning of file for next read
	instruction_File.close();
}
//***********************************************************
//***********************************************************
void player_1::zero_Screen()							// function to read from file containing plane picture
{
	ifstream center_File;
	center_File.open ("maintenance\\screen_Zero.txt", ios::in);

	if(!center_File)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"screen_Zero.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = center_File.get()) != EOF)
		{
			cout << pix;
		}		
	center_File.seekg(0);								//move to the beginnning of file for next read
	center_File.close();
}
//***********************************************************
//***********************************************************
void player_1::clear_Screen_Return()							// function to read from file containing plane picture
{
	ifstream new_Scrn;

	do{
		pix = cin.get();
		if(pix != '\n')
		{
			cin.ignore(75,'\n');
		}
	}while(pix !='\n');

	new_Scrn.open ("maintenance\\screen_Clear.txt", ios::in);

	if(!new_Scrn)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"maintenance\\screen_Clear.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = new_Scrn.get()) != EOF)
		{
			cout << pix;
		}		
	new_Scrn.seekg(0);								//move to the beginnning of file for next read
	new_Scrn.close();
//	cout << "\b";
}
//***********************************************************
//***********************************************************
void player_1::clear_Screen()						// function to read from file containing plane picture
{
	ifstream new_Scrn;

	new_Scrn.open ("maintenance\\screen_Clear.txt", ios::in);

	if(!new_Scrn)									// standard form of error checking for this?  Try loop not necessary
		{
			cerr << "File \"maintenance\\screen_Clear.txt\" could not be found."<< endl;		// I hope this works...test it.
			exit(1);
		}

	while((pix = new_Scrn.get()) != EOF)
		{
			cout << pix;
		}		
	new_Scrn.seekg(0);								//move to the beginnning of file for next read
	new_Scrn.close();
}
//***********************************************************
//***********************************************************

void player_1::enter_Name()
{
	fstream player_File;

	cout << "\nEnter your title: ";
	cin.getline(title, 40);							// retrieve up to 30 char for title							// dump all extra stuff up to '\n'

	cout << "\nEnter your name: ";
	cin.getline( name, 40);

	player_File.open( "maintenance\\player_File.txt", ios::app );
	player_File << title << " ";			// '+' char delineates entries and output

	player_File << name << '+' << endl;
	player_File.close();

}
//***********************************************************
//***********************************************************
void player_1::clear_File()					// clear player's data file for new game
{
	fstream file;
	file.open("maintenance\\player_File.txt", ios::trunc);
	file.close();
}
//***********************************************************
//***********************************************************
void player_1::display_Full_Name()			// function to display character name
{
	char c;

	cout << endl;
	player_File.open("maintenance\\player_File.txt",ios::in);

		while((c = player_File.get()) != '+')
			cout << c;
			cout << " ";

	player_File.close();
	cout <<"\b";
}
//***********************************************************
//***********************************************************
void player_1::save_File()				// Save game entries in data file to floppy
{
	char c;								// hold variable for file transfer
	fstream save_File;
	fstream last_Game;

	save_File.open("A:\\my_RPG_Game.txt", ios::out);
	last_Game.open("player_File.txt", ios::in|ios::nocreate );

	while ( (c = last_Game.get()) != EOF )			// while not end of file, write to 
	{												//...floppy disk for game save
		save_File << c;
	}

	save_File.close();								// close both files
	last_Game.close();
}


	