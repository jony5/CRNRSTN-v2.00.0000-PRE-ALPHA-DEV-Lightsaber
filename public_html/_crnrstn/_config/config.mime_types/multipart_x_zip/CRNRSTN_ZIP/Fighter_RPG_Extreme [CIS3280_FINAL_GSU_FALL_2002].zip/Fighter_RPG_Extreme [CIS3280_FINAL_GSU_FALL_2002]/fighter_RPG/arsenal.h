/*
File:				arsenal.h
Programmer:			Jonathan Harris
Last Modified:		11.24.2002
Description:		This is an attempt at a class to manipulate the
					weapons for a player.  By making this abstract, cool...
*/

#include "player_1.h"

#ifndef ARSENAL_H
#define ARSENAL_H

class arsenal : public player_1 {
public:
	arsenal();
	~arsenal();
	void opening_Menu();					// display opening menu
	void add_Arms_Menu();					// add item menu
	void remove_Arms_Menu();				// remove item menu

private:
		int flare;
		int chaff;
		int aim;
		int sidewind;

//**********************************************************	
	char pix;					// DO NOT DELETE charater var for file reading
//**********************************************************
};
#endif